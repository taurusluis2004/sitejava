// Função para pré-visualizar a imagem selecionada
function previewImage(event) {
    const input = event.target; // Obtém o input de arquivo
    const previewImg = document.getElementById('previewImg'); // Obtém o elemento de imagem de pré-visualização
    const resultDiv = document.getElementById('result'); // Obtém a div de resultados
    resultDiv.innerText = ''; // Limpa o resultado anterior

    console.log('Imagem selecionada:', input.files[0]);

    // Verifica se há um arquivo selecionado
    if (input.files && input.files[0]) {
        const reader = new FileReader(); // Cria um FileReader para ler o arquivo
        reader.onload = function(e) {
            previewImg.src = e.target.result; // Define a fonte da imagem de pré-visualização
            document.getElementById('identifyButton').style.display = 'inline-block'; // Mostra o botão de identificar
            console.log('Imagem pré-visualizada');
        };
        reader.readAsDataURL(input.files[0]); // Lê o arquivo como URL de dados
    } else {
        previewImg.src = ''; // Limpa a imagem de pré-visualização
        document.getElementById('identifyButton').style.display = 'none'; // Oculta o botão de identificar
    }
}

// Função para identificar o alimento na imagem carregada
async function identifyFood() {
    console.log('Iniciando identificação...');
    const input = document.getElementById('imageUpload'); // Obtém o input de arquivo
    const identifyButton = document.getElementById('identifyButton'); // Obtém o botão de identificar
    const loadingDiv = document.getElementById('loading'); // Obtém a div de carregamento
    const resultDiv = document.getElementById('result'); // Obtém a div de resultados
    const resultContainer = document.getElementById('resultContainer'); // Obtém o contêiner de resultados
    const newImageButton = document.getElementById('newImageButton'); // Obtém o botão de nova imagem

    // Verifica se um arquivo foi selecionado
    if (input.files.length === 0) {
        alert('Por favor, selecione uma imagem.');
        return;
    }

    // Oculta e mostra elementos relevantes durante o processamento
    identifyButton.style.display = 'none'; // Oculta o botão de identificar
    loadingDiv.style.display = 'flex'; // Mostra a div de carregamento
    resultDiv.innerText = ''; // Limpa o resultado anterior
    resultContainer.style.display = 'none'; // Oculta o contêiner de resultados

    const file = input.files[0]; // Obtém o arquivo
    const reader = new FileReader(); // Cria um FileReader para ler o arquivo
    reader.onloadend = async function () {
        const arrayBuffer = reader.result; // Obtém o resultado como ArrayBuffer
        console.log('Arquivo lido:', arrayBuffer);

        try {
            // URL da API correta para seu projeto no Azure Custom Vision
            const apiUrl = 'https://kauanhauger20-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction/88c9b734-0300-47f4-bbda-7201738c156e/detect/iterations/Iteration8/url';

            // Faz a requisição à API de reconhecimento de alimentos
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Prediction-Key': '1b94c6fa133f4ab18e2e496b27e12f3f',
                    'Content-Type': 'application/octet-stream'
                },
                body: arrayBuffer // Envia o arquivo como corpo da requisição
            });

            const result = await response.json(); // Converte a resposta para JSON
            console.log('Resposta da API:', result);

            loadingDiv.style.display = 'none'; // Oculta a div de carregamento
            resultContainer.style.display = 'flex'; // Mostra o contêiner de resultados
            newImageButton.style.display = 'block'; // Mostra o botão de nova imagem

            // Mostra o resultado do reconhecimento
            if (result.predictions && result.predictions.length > 0) {
                resultDiv.innerText = `Comida: ${result.predictions[0].tagName}`;
            } else {
                resultDiv.innerText = 'Comida não reconhecida';
            }
        } catch (error) {
            console.error('Erro ao chamar a API de reconhecimento:', error);
            resultDiv.innerText = 'Erro ao reconhecer a comida. Por favor, tente novamente.';
            loadingDiv.style.display = 'none'; // Oculta a div de carregamento
            identifyButton.style.display = 'inline-block'; // Mostra o botão de identificar novamente
        }
    };
    reader.readAsArrayBuffer(file); // Lê o arquivo como ArrayBuffer
}

// Função para resetar a interface de carregamento de imagens
function reset() {
    document.getElementById('imageUpload').value = ''; // Limpa o input de arquivo
    document.getElementById('previewImg').src = ''; // Limpa a imagem de pré-visualização
    document.getElementById('identifyButton').style.display = 'none'; // Oculta o botão de identificar
    document.getElementById('loading').style.display = 'none'; // Oculta a div de carregamento
    document.getElementById('resultContainer').style.display = 'none'; // Oculta o contêiner de resultados
    document.getElementById('newImageButton').style.display = 'none'; // Oculta o botão de nova imagem
    document.getElementById('result').innerText = ''; // Limpa o resultado anterior
    console.log('Interface resetada');
}

package app;
import dao.DAO;
import dao.Alimentodao;


import static spark.Spark.*;

import service.UsuarioService;
import service.AlimentoService;

public class Aplicacao {
	
	private static UsuarioService usuarioService = new UsuarioService();
	private static AlimentoService alimentoService=new AlimentoService();
    public static void main(String[] args) {
    
        port(6789);
        

        post("/usuario", (request, response) -> usuarioService.add(request, response));

        get("/usuario/:id", (request, response) -> usuarioService.get(request, response));
        get("/usuario/updateinfo/:nome", (request, response) -> usuarioService.get(request, response));
        post("/usuario/login", (request, response) -> usuarioService.login(request, response));

        post("/usuario/update", (request, response) -> usuarioService.update(request, response));

        get("/usuario/delete/:id", (request, response) -> usuarioService.remove(request, response));

        get("/usuario", (request, response) -> usuarioService.getAll(request, response));
        
        get("/usuario/search/:username", (request, response) -> usuarioService.search(request, response));
        get("/usuario/search", (request, response) -> usuarioService.searchogro(request, response));
        post("/alimento", (request, response) -> alimentoService.add(request, response));

        get("/alimento/:id", (request, response) -> alimentoService.get(request, response));

        get("/alimento/update/:id", (request, response) -> alimentoService.update(request, response));

        get("/alimento/delete/:id", (request, response) -> alimentoService.remove(request, response));

        get("/alimento", (request, response) -> alimentoService.getAll(request, response));
        
        
               
    }
}
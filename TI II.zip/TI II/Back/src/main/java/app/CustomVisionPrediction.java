package app;

public class CustomVisionPrediction {

}

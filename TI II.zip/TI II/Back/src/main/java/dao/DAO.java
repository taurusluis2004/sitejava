package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Usuario;

import model.Usuario;

public class DAO {
    public int maxid;
    private Connection conexao;
    private List<Usuario> usuariosPostgre;

    public DAO() {
        conexao = null;
        maxid = -1;
    }

    public boolean conectar() {
        String driverName = "org.postgresql.Driver";
        String serverName = "localhost";
        String mydatabase = "postgres";
        int porta = 5432;
        String url = "jdbc:postgresql://" + serverName + ":" + porta + "/" + mydatabase;
        String username = "postgres";
        String password = "123";
        boolean status = false;

        try {
            Class.forName(driverName);
            conexao = DriverManager.getConnection(url, username, password);
            status = (conexao != null);
            System.out.println("Conexão efetuada com o postgres!");
        } catch (ClassNotFoundException e) {
            System.err.println("Conexão NÃO efetuada com o postgres -- Driver não encontrado -- " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Conexão NÃO efetuada com o postgres -- " + e.getMessage());
        }

        return status;
    }

    public boolean close() {
        boolean status = false;

        try {
            conexao.close();
            status = true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return status;
    }

    public int maxid() {
        int maxid = -1;
        try {
            for (Usuario usuario : usuariosPostgre) {
                System.out.println(usuario.getId());
                if (usuario.getId() > maxid) {
                    maxid = usuario.getId();
                }
            }
            System.out.println("maxima de " + maxid);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return maxid;
    }

    public boolean inserirUsuario(Usuario usuario) {
        boolean status = false;
        String sql = "INSERT INTO usuarios (id, nome, peso, altura, senha, email) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setInt(1, usuario.getId());
            pst.setString(2, usuario.getNome());
            pst.setFloat(3, usuario.getPeso());
            pst.setInt(4, usuario.getAlt()); // altura como int
            pst.setString(5, usuario.getSenha());
            pst.setString(6, usuario.getEmail());
            pst.executeUpdate();
            pst.close();
            usuariosPostgre.add(usuario);
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean atualizarUsuario(Usuario usuario) {
    	System.out.println(usuario.getNome());
        boolean status = false;
        String sql = "UPDATE usuarios SET nome = ?, peso = ?, altura = ?, email = ?, senha = ? WHERE id = ?";
        try {
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setString(1, usuario.getNome());
            pst.setFloat(2, usuario.getPeso());
            pst.setInt(3, usuario.getAlt());
            pst.setString(4, usuario.getEmail());
            pst.setString(5, usuario.getSenha());
            pst.setInt(6, usuario.getId());
            pst.executeUpdate();
            pst.close();
            
            int index = usuariosPostgre.indexOf(usuario);
            if (index != -1) {
                usuariosPostgre.set(index, usuario);
            }

            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

	

    public boolean excluirUsuario(Usuario usuario) {
        boolean status = false;
        String sql = "DELETE FROM usuarios WHERE id = ?";
        try {
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setInt(1, usuario.getId());
            pst.executeUpdate();
            pst.close();
            status = true;

            int index = usuariosPostgre.indexOf(usuario);
            if (index != -1) {
                usuariosPostgre.remove(index);
            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public Usuario get(int id) {
        System.out.println(usuariosPostgre.get(0).getId());
        System.out.println(id);
        for (Usuario usuario : usuariosPostgre) {
            System.out.println(usuario.getId());
            if (id == usuario.getId()) {
            	 System.out.println(usuario.getNome());
                return usuario;
            }
        }
        return null;
    }

    public Usuario pesquisar_nome(String nome) {
        for (Usuario usuario : usuariosPostgre) {
            System.out.println("ativou funcao");
            if (nome.compareTo(usuario.getNome()) == 0) {
                System.out.println("usuario encontrado" + usuario.getNome());
                return usuario;
            }
        }
        return null;
    }
    
    public Usuario pesquisar_senha(String senha) {
        for (Usuario usuario : usuariosPostgre) {
            System.out.println("ativou funcao");
            if (senha.compareTo(usuario.getSenha()) == 0) {
                System.out.println("usuario encontrado" + usuario.getSenha());
                return usuario;
            }
        }
        return null;
    }
    
    public Usuario login(String nome, String senha) {
        for (Usuario usuario : usuariosPostgre) {
            System.out.println("Ativou função login");
            if (usuario.getNome().equals(nome) && usuario.getSenha().equals(senha)) {
                System.out.println("Usuário encontrado: " + usuario.getNome());
                return usuario;
            }
        }
        return null;
    }

    
    
    

    public void iniciar() {
        try {
            usuariosPostgre = new ArrayList<Usuario>();
            String sql = "SELECT * FROM usuarios";
            PreparedStatement pst = conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                rs.last();
                rs.beforeFirst();

                while (rs.next()) {
                    Usuario usuario = new Usuario(rs.getInt("id"), rs.getString("nome"), rs.getFloat("peso"), rs.getInt("altura"), rs.getString("senha"), rs.getString("email"));
                    System.out.println(usuario.getNome()+"aaaaaaa");
                    
                    usuariosPostgre.add(usuario);
                }
            }
            pst.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public Usuario[] getUsuarios() {
        Usuario[] usuarios = null;

        try {
            String sql = "SELECT * FROM usuarios";
            PreparedStatement pst = conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                rs.last();
                usuarios = new Usuario[rs.getRow()];
                rs.beforeFirst();

                for (int i = 0; rs.next(); i++) {
                    usuarios[i] = new Usuario(rs.getInt("id"), rs.getString("nome"), rs.getFloat("peso"), rs.getInt("altura"), rs.getString("senha"), rs.getString("email"));
                    System.out.println(usuarios[i].getNome()+"bbbbbbbbb");
                }
            }
            pst.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return usuarios;
    }
}

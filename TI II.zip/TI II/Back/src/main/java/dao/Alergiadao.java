package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import model.Alergia;
//import dao.AlergiaAlergiadao;

public class Alergiadao {
public int maxid;
	private Connection conexao;
	private List<Alergia> alergiasPostgre;
	
	public Alergiadao() {
		conexao = null;
	maxid=-1;
		
	}


	public boolean conectar() {
		String driverName = "org.postgresql.Driver";                    
		String serverName = "localhost";
		String mydatabase = "postgres";
		int porta = 5432;
		String url = "jdbc:postgresql://" + serverName + ":" + porta +"/" + mydatabase;
		String username = "postgres";
		String password = "123";
		boolean status = false;

		try {
			Class.forName(driverName);
			conexao = DriverManager.getConnection(url, username, password);
			status = (conexao == null);
			System.out.println("Conexão efetuada com o postgres!");
			
		
			
		} catch (ClassNotFoundException e) { 
			System.err.println("Conexão NÃO efetuada com o postgres -- Driver não encontrado -- " + e.getMessage());
		} catch (SQLException e) {
			System.err.println("Conexão NÃO efetuada com o postgres -- " + e.getMessage());
		}

		return status;
	}
	
	public boolean close() {
		boolean status = false;
		
		try {
			conexao.close();
			status = true;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return status;
	}

	public int maxid(){
		int maxid=-1;
	try {
		
		for (Alergia alergia : alergiasPostgre) {
			System.out.println(alergia.getId());
			if (alergia.getId()>maxid) {
maxid=alergia.getId();
				
			}

		}}catch (Exception e) {
		System.err.println(e.getMessage());
	}
	 return maxid;
	}
	
	public boolean inserirAlergia(Alergia alergia) {
		boolean status = false;
		try {  
			
			Statement st = conexao.createStatement();
			st.executeUpdate("INSERT INTO alergias (id, nome, usuario_id, alimento_id) "
					       + "VALUES ("+alergia.getId()+ ", '" + alergia.getNome() + "', "  
					       + alergia.getUsuario_id() + ", " + alergia.getAlimento_id() + " );");
			
			st.close();
		alergiasPostgre.add(alergia);
			
			status = true;
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public boolean atualizarAlergia(Alergia alergia) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			String sql = "UPDATE alergia SET nome = '" + alergia.getNome() + "', usuario_id = '"  
				       + alergia.getUsuario_id() + "', alimento_id = '" + alergia.getAlimento_id() + "'"
					   + " WHERE id = " + alergia.getId();
			st.executeUpdate(sql);
			st.close();
			status = true;
			
				int index = alergiasPostgre.indexOf(alergia);
				if (index != -1) {
					alergiasPostgre.set(index, alergia);
				
				}
			

		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public boolean excluirAlergia(Alergia alergia) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			st.executeUpdate("DELETE FROM alergia WHERE id = " + alergia.getId());
			st.close();
			status = true;
			int index = alergiasPostgre.indexOf(alergia);
		
				alergiasPostgre.remove(index);
			
			
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public Alergia get(int id) {
		System.out.println(alergiasPostgre.get(0).getId());
		System.out.println(id);
		for (Alergia alergia : alergiasPostgre) {
			System.out.println(alergia.getId());
			if (id == alergia.getId()) {

				return alergia;
			}
		}
		return null;
	}
	
	public void iniciar() {
		
		try {
			alergiasPostgre = new ArrayList<Alergia>();
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery("SELECT * FROM alergias");		
	         if(rs.next()){
	             rs.last();
	          
	             rs.beforeFirst();

	             for(int i = 0; rs.next(); i++) {
	            	
	            	 
	            	 
	                Alergia alergia = new Alergia(rs.getInt("id"), rs.getString("nome"), 
	                		                  rs.getInt("usuario_id"), rs.getInt("alimento_id"));
	                System.out.println(alergia.getId());
	                alergiasPostgre.add(alergia);
	                
	             }
	             
	             
	          }
	          st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		
	}
	public Alergia[] getAlergias() {
		Alergia[] alergias = null;
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery("SELECT * FROM alergias");		
	         if(rs.next()){
	             rs.last();
	             alergias = new Alergia[rs.getRow()];
	             rs.beforeFirst();

	             for(int i = 0; rs.next(); i++) {
	            	
	            	 
	            	 
	                alergias[i] = new Alergia(rs.getInt("id"), rs.getString("nome"), 
	                		                  rs.getInt("usuario_id"), rs.getInt("alimento_id"));
	                
	             }
	             
	             
	          }
	          st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return alergias;
	}
 

}


package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Alimento;

public class Alimentodao {
    private Connection conexao;
    private List<Alimento> alimentosPostgre;

    public Alimentodao() {
        conexao = null;
        alimentosPostgre = new ArrayList<>();
    }

    public boolean conectar() {
        String driverName = "org.postgresql.Driver";
        String serverName = "localhost";
        String mydatabase = "postgres";
        int porta = 5432;
        String url = "jdbc:postgresql://" + serverName + ":" + porta + "/" + mydatabase;
        String username = "postgres";
        String password = "123";
        boolean status = false;

        try {
            Class.forName(driverName);
            conexao = DriverManager.getConnection(url, username, password);
            status = (conexao != null);
            System.out.println("Conexão efetuada com o postgres!");
        } catch (ClassNotFoundException e) {
            System.err.println("Conexão NÃO efetuada com o postgres -- Driver não encontrado -- " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Conexão NÃO efetuada com o postgres -- " + e.getMessage());
        }

        return status;
    }

    public boolean close() {
        boolean status = false;

        try {
            if (conexao != null) {
                conexao.close();
                status = true;
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return status;
    }

    public int maxid() {
        int maxid = -1;
        try {
            for (Alimento alimento : alimentosPostgre) {
                if (alimento.getId() > maxid) {
                    maxid = alimento.getId();
                }
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return maxid;
    }

    public boolean inserirAlimento(Alimento alimento) {
        boolean status = false;
        try {
            String sql = "INSERT INTO alimentos (id, nome_alimento, proteinas, calorias) VALUES (?, ?, ?, ?)";
            PreparedStatement st = conexao.prepareStatement(sql);
            st.setInt(1, alimento.getId());
            st.setString(2, alimento.getNome());
            st.setInt(3, alimento.getProteinas());
            st.setInt(4, alimento.getCalorias());

            st.executeUpdate();
            st.close();

            alimentosPostgre.add(alimento);

            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean atualizarAlimento(Alimento alimento) {
        boolean status = false;
        try {
            String sql = "UPDATE alimentos SET nome_alimento = ?, proteinas = ?, calorias = ? WHERE id = ?";
            PreparedStatement st = conexao.prepareStatement(sql);
            st.setString(1, alimento.getNome());
            st.setInt(2, alimento.getProteinas());
            st.setInt(3, alimento.getCalorias());
            st.setInt(4, alimento.getId());

            st.executeUpdate();
            st.close();

            int index = alimentosPostgre.indexOf(alimento);
            if (index != -1) {
                alimentosPostgre.set(index, alimento);
            }

            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean excluirAlimento(Alimento alimento) {
        boolean status = false;
        try {
            String sql = "DELETE FROM alimentos WHERE id = ?";
            PreparedStatement st = conexao.prepareStatement(sql);
            st.setInt(1, alimento.getId());

            st.executeUpdate();
            st.close();

            int index = alimentosPostgre.indexOf(alimento);
            if (index != -1) {
                alimentosPostgre.remove(index);
            }

            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public Alimento get(int id) {
        for (Alimento alimento : alimentosPostgre) {
            if (id == alimento.getId()) {
                return alimento;
            }
        }
        return null;
    }

    public Alimento pesquisar_alimento(String nomealimento) {
        if (nomealimento != null) {
            for (Alimento alimento : alimentosPostgre) {
                if (nomealimento.compareTo(alimento.getNome()) == 0) {
                    return alimento.getNome();
                }
            }
        }
        return alimento;
    }

    public void iniciar() {
        try {
            alimentosPostgre.clear(); // Limpa a lista antes de iniciar

            String sql = "SELECT * FROM alimentos";
            PreparedStatement st = conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Alimento alimento = new Alimento(rs.getInt("id"), rs.getString("nome_alimento"),
                        rs.getInt("proteinas"), rs.getInt("calorias"), rs.getInt("usuario_id"));
                alimentosPostgre.add(alimento);
            }

            st.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public Alimento[] getAlimentos() {
        Alimento[] alimentos = null;

        try {
            String sql = "SELECT * FROM alimentos";
            PreparedStatement st = conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                rs.last();
                alimentos = new Alimento[rs.getRow()];
                rs.beforeFirst();

                int i = 0;
                while (rs.next()) {
                    alimentos[i] = new Alimento(rs.getInt("id"), rs.getString("nome_alimento"),
                            rs.getInt("proteinas"), rs.getInt("calorias"), rs.getInt("usuario_id"));
                    i++;
                }
            }

            st.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return alimentos;
    }
}

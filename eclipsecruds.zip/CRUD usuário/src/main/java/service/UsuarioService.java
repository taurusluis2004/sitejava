package service;
import dao.DAO;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import dao.DAO;
import model.Alergia;
//import dao.UsuarioDAO;
import model.Usuario;
import spark.Request;
import spark.Response;
import dao.Alergiadao;
import dao.Alimentodao;

public class UsuarioService {
	
	
	//static DAO dao = new DAO();


	//private UsuarioDAO usuarioDAO;
	private DAO dao;
	private Alergiadao alergiadao;
	private Alimentodao alimentodao;

	public UsuarioService() {
		try {
			//usuarioDAO = new UsuarioDAO("usuario.dat");
			dao=new DAO();
		
			
			alergiadao=new Alergiadao();
			alimentodao=new Alimentodao();
			alimentodao.conectar();
			alimentodao.iniciar();
		alergiadao.conectar();
		alergiadao.iniciar();
			dao.conectar();
			dao.iniciar();
		} catch (Exception  e) {
			System.out.println(e.getMessage());
		}
	}

	public Object add(Request request, Response response) {
		String nome = request.queryParams("nome");
		System.out.println(nome+"aaaa");
		float peso = Float.parseFloat(request.queryParams("peso"));
		System.out.println(peso);
		int altura = Integer.parseInt(request.queryParams("altura"));
		System.out.println(altura);
		String senha = request.queryParams("senha");
		String email = request.queryParams("email");
		String alergianome = request.queryParams("alergias");
		
		//int id = usuarioDAO.getMaxId() + 1;
int id_usuario=dao.maxid()+1;
System.out.println("id_usuario"+id_usuario);
int id_alergia=alergiadao.maxid()+1;

		Usuario usuario = new Usuario(id_usuario,nome,peso,altura,senha,email);
		//int id_alimento=alimentodao.pesquisar(alergianome);
		
		//Alergia alergia=new Alergia(id_alergia,alergianome,id_usuario,id_alimento);

		//usuarioDAO.add(usuario);
dao.inserirUsuario(usuario);
//System.out.println(alergia.getNome());

		response.status(201); // 201 Created
		return id_usuario;
	}

	public Object get(Request request, Response response) {
		int id = Integer.parseInt(request.params(":id"));
		
		//Usuario usuario = (Usuario) usuarioDAO.get(id);
		Usuario usuario = (Usuario) dao.get(id);
		
		if (usuario != null) {
    	    response.header("Content-Type", "application/xml");
    	    response.header("Content-Encoding", "UTF-8");

            return "<usuario>\n" + 
            		"\t<id>" + usuario.getId() + "</id>\n" +
            		"\t<nome>" + usuario.getNome() + "</nome>\n" +
            		"\t<peso>" + usuario.getPeso() + "</peso>\n" +
            		"\t<altura>" + usuario.getAlt() + "</altura>\n" +
            		//"\t<fabricacao>" + usuario.getSenha() + "</fabricacao>\n" +
            		//"\t<validade>" + usuario.getDataValidade() + "</validade>\n" +
            		"</usuario>\n";
        } else {
            response.status(404); // 404 Not found
            return "Usuario " + id + " não encontrado.";
        }

	}
	public Object searchogro(Request request, Response response) {
		 return "Usuario " +" ogro.";
		
		
		
		//Usuario usuario = (Usuario) usuarioDAO.get(id);
	

	}
	/*public Object search(Request request, Response response) {
		String nome  = request.params(":username");
		
		
		
		//Usuario usuario = (Usuario) usuarioDAO.get(id);
		Usuario usuario = (Usuario) dao.pesquisar_nome(nome);
		
		if (usuario != null) {
    	    response.header("Content-Type", "application/xml");
    	    response.header("Content-Encoding", "UTF-8");

            return "<usuario>\n" + 
            		"\t<id>" + usuario.getId() + "</id>\n" +
            		"\t<nome>" + usuario.getNome() + "</nome>\n" +
            		"\t<peso>" + usuario.getPeso() + "</peso>\n" +
            		"\t<altura>" + usuario.getAlt() + "</altura>\n" +
            		//"\t<fabricacao>" + usuario.getSenha() + "</fabricacao>\n" +
            		//"\t<validade>" + usuario.getDataValidade() + "</validade>\n" +
            		"</usuario>\n";
        } else {
            response.status(404); // 404 Not found
            return "Usuario " + nome + " não encontrado.";
        }

	}
	*/
	public Object search(Request request, Response response) {
	    String nome = request.params(":username");
	    String senha = request.params(":password");

	    //Usuario usuario = (Usuario) usuarioDAO.get(id);
	    Usuario usuario = (Usuario) dao.pesquisar_nome(nome);

	    if (usuario != null) {
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlResponse = "<html>\n" +
	                "<head>\n" +
	                "<meta http-equiv=\"refresh\" content=\"5;url=conta.html\">\n" + // Redireciona após 5 segundos
	                "<title>Usuário Encontrado</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Usuário</h1>\n" +
	                "<p>ID: " + usuario.getId() + "</p>\n" +
	                "<p>Nome: " + usuario.getNome() + "</p>\n" +
	                "<p>Peso: " + usuario.getPeso() + "</p>\n" +
	                "<p>Altura: " + usuario.getAlt() + "</p>\n" +
	                "<p>log in efetuado</p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlResponse;
	    } else {
	        response.status(404); // 404 Not Found
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlErrorResponse = "<html>\n" +
	                "<head>\n" +
	                "<title>Erro 404</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Erro 404</h1>\n" +
	                "<p>Usuário " + nome + " não encontrado.</p>\n" +
	                "<p><a href=\"conta.html\">Voltar para Conta</a></p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlErrorResponse;
	    }
	}
	
	
	
	
	
	public Object searchnome(Request request, Response response) {
	    String nome = request.params(":username");
	    

	    //Usuario usuario = (Usuario) usuarioDAO.get(id);
	    Usuario usuario = (Usuario) dao.pesquisar_nome(nome);

	    if (usuario != null) {
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlResponse = "<html>\n" +
	                "<head>\n" +
	                "<meta http-equiv=\"refresh\" content=\"5;url=conta.html\">\n" + // Redireciona após 5 segundos
	                "<title>Usuário Encontrado</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Usuário</h1>\n" +
	                "<p>ID: " + usuario.getId() + "</p>\n" +
	                "<p>Nome: " + usuario.getNome() + "</p>\n" +
	                "<p>Peso: " + usuario.getPeso() + "</p>\n" +
	                "<p>Altura: " + usuario.getAlt() + "</p>\n" +
	                "<p>log in efetuado</p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlResponse;
	    } else {
	        response.status(404); // 404 Not Found
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlErrorResponse = "<html>\n" +
	                "<head>\n" +
	                "<title>Erro 404</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Erro 404</h1>\n" +
	                "<p>Usuário " + nome + " não encontrado.</p>\n" +
	                "<p><a href=\"conta.html\">Voltar para Conta</a></p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlErrorResponse;
	    }
	}
	public static String hashSenhaToMD5(String senha) {
        try {
            // Create MessageDigest instance for MD5
            MessageDigest md = MessageDigest.getInstance("MD5");
            
            // Add name bytes to digest
            md.update(senha.getBytes());
            
            // Get the hash's bytes
            byte[] bytes = md.digest();
            
            // Convert it to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            
            // Get complete hashed name in hex format
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
	
	public Object login(Request request, Response response) {
		
		String nome = request.queryParams("nome");
	    System.out.println(nome);
	    String senha = request.queryParams("senha");
	  String  senhahash=  hashSenhaToMD5(senha);
System.out.println("login executado ");
	    //Usuario usuario = (Usuario) usuarioDAO.get(id);
	    Usuario usuario = (Usuario) dao.login(nome,senhahash);
	    

	    if (usuario != null) {
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlResponse = "<html>\n" +
	                "<head>\n" +
	                "<meta http-equiv=\"refresh\" content=\"5;url=conta.html\">\n" + // Redireciona após 5 segundos
	                "<title>Usuário Encontrado</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Usuário</h1>\n" +
	                "<p>ID: " + usuario.getId() + "</p>\n" +
	                "<p>Nome: " + usuario.getNome() + "</p>\n" +
	                "<p>Peso: " + usuario.getPeso() + "</p>\n" +
	                "<p>Altura: " + usuario.getAlt() + "</p>\n" +
	                "<p>log in efetuado</p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlResponse;
	    } else {
	        response.status(404); // 404 Not Found
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlErrorResponse = "<html>\n" +
	                "<head>\n" +
	                "<title>Erro 404</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Erro 404</h1>\n" +
	                "<p>Usuário " + nome + " ecnontrado.</p>\n" +
	                "<p><a href=\"conta.html\">Voltar para Conta</a></p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlErrorResponse;
	    }
	}
	
	

	/*public Object search(Request request, Response response) {
	    String nome = request.params(":username");
	    //String senha = request.params(":password");

	    //Usuario usuario = (Usuario) usuarioDAO.get(id);
	    Usuario usuario = (Usuario) dao.pesquisar_nome(nome);

	    if (usuario != null) {
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlResponse = "<html>\n" +
	                "<head>\n" +
	                "<meta http-equiv=\"refresh\" content=\"5;url=conta.html\">\n" + // Redireciona após 5 segundos
	                "<title>Usuário Encontrado</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Usuário</h1>\n" +
	                "<p>ID: " + usuario.getId() + "</p>\n" +
	                "<p>Nome: " + usuario.getNome() + "</p>\n" +
	                "<p>Peso: " + usuario.getPeso() + "</p>\n" +
	                "<p>Altura: " + usuario.getAlt() + "</p>\n" +
	                "<p>Você será redirecionado para <a href=\"conta.html\">conta.html</a> em 5 segundos.</p>\n" +
	                "<script> \n  window.location.href = 'conta.html';  </script>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlResponse;
	    } else {
	        response.status(404); // 404 Not Found
	        response.header("Content-Type", "text/html");
	        response.header("Content-Encoding", "UTF-8");

	        String htmlErrorResponse = "<html>\n" +
	                "<head>\n" +
	                "<title>Erro 404</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Erro 404</h1>\n" +
	                "<p>Usuário " + nome + " não encontrado.</p>\n" +
	                "<p><a href=\"conta.html\">Voltar para Conta</a></p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlErrorResponse;
	    }
	}
	*/
	



	public Object update(Request request, Response response) {
        int id = Integer.parseInt(request.queryParams("id"));
        
		Usuario usuario = (Usuario) dao.get(id);

        if (usuario != null) {
        	System.out.println(usuario.getNome());
        	usuario.setNome(request.queryParams("nome"));
        	usuario.setPeso(Float.parseFloat(request.queryParams("peso")));
        	usuario.setAlt(Integer.parseInt(request.queryParams("altura")));
        	usuario.setNome(request.queryParams("senha"));
        	usuario.setEmail(request.queryParams("email"));

        	dao.atualizarUsuario(usuario);
        	
            return id;
        } else {
            response.status(404); // 404 Not found
            return "Usuario não encontrado.";
        }

	}
	
	

	public Object remove(Request request, Response response) {
        int id = Integer.parseInt(request.params(":id"));

        Usuario usuario = (Usuario) dao.get(id);

        if (usuario != null) {

           dao.excluirUsuario(usuario);

            response.status(200); // success
        	return id;
        } else {
            response.status(404); // 404 Not found
            return "Usuario não encontrado.";
        }
	}

	public Object getAll(Request request, Response response) {
	    StringBuffer returnValue = new StringBuffer(
	        "<!DOCTYPE html>\n" +
	        "<html lang=\"en\">\n" +
	        "<head>\n" +
	        "    <meta charset=\"UTF-8\">\n" +
	        "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
	        "    <title>Lista de Usuários</title>\n" +
	        "    <style>\n" +
	        "        table {\n" +
	        "            width: 100%;\n" +
	        "            border-collapse: collapse;\n" +
	        "        }\n" +
	        "        table, th, td {\n" +
	        "            border: 1px solid black;\n" +
	        "        }\n" +
	        "        th, td {\n" +
	        "            padding: 15px;\n" +
	        "            text-align: left;\n" +
	        "        }\n" +
	        "        th {\n" +
	        "            background-color: #f2f2f2;\n" +
	        "        }\n" +
	        "    </style>\n" +
	        "</head>\n" +
	        "<body>\n" +
	        "    <h1>Lista de Usuários</h1>\n" +
	        "    <table>\n" +
	        "        <tr>\n" +
	        "            <th>ID</th>\n" +
	        "            <th>Nome</th>\n" +
	        "            <th>Peso</th>\n" +
	        "            <th>Altura</th>\n" +
	        "            <th>email</th>\n" +
	        
	        "            <th>senha</th>\n" +
	        
	        "        </tr>\n");

	    for (Usuario usuario : dao.getUsuarios()) {
	        returnValue.append(
	            "        <tr>\n" +
	            "            <td>" + usuario.getId() + "</td>\n" +
	            "            <td>" + usuario.getNome() + "</td>\n" +
	            "            <td>" + usuario.getPeso() + "</td>\n" +
	            "            <td>" + usuario.getAlt() + "</td>\n" +
	            "            <td>" + usuario.getEmail() + "</td>\n" +
	            "            <td>" + usuario.getSenha() + "</td>\n" +
	            "        </tr>\n"
	        );
	    }

	    returnValue.append(
	        "    </table>\n" +
	        "</body>\n" +
	        "</html>\n"
	    );

	    response.header("Content-Type", "text/html");
	    response.header("Content-Encoding", "UTF-8");
	    return returnValue.toString();
	}

}
package model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Alimento implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String DESCRICAO_PADRAO = "Novo alimento";
	public static final int MAX_ESTOQUE = 1000;
	private int id;
	private String descricao;
	private int  proteinas;
	private int calorias;
	private int usuario_id;
	private String nome;
	
	public Alimento() {
		id = -1;
		descricao = DESCRICAO_PADRAO;
		proteinas = 0;
		calorias = 0;
	
	}

	public Alimento(int id, String nome, int  proteinas, int calorias,int usuario_id) {
		setId(id);
		//setDescricao(descricao);
		setProteinas(proteinas);
		setNome(nome);
	setCalorias(calorias);
		
	}		
	
	public int getId() {
		return id;
	}
	

	public void setId(int id) {
		this.id = id;
	}
	public int getUsuario_id() {
		return this.usuario_id;
	}
	
	public void setUsuario_id(int usuario_id) {
		this.usuario_id = usuario_id;
	}
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	
	/*public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		if (descricao.length() >= 3)
			this.descricao = descricao;
	*/

	public int getProteinas() {
		return proteinas;
	}

	public void setProteinas(int proteinas) {
		if (proteinas >0)
			this.proteinas = proteinas;
	}

	public int getCalorias() {
		return calorias;
	}
	
	public void setCalorias(int calorias) {
	
			this.calorias = calorias;
	}
	
	

	

	





	/**
	 * Método sobreposto da classe Object. É executado quando um objeto precisa
	 * ser exibido na forma de String.
	 */
	@Override
	public String toString() {
		return "Produto: " + descricao + "   Preço: R$" + proteinas + "   Quant.: " + calorias ;
	}
	
	@Override
	public boolean equals(Object obj) {
		return (this.getId() == ((Alimento) obj).getId());
	}	
}